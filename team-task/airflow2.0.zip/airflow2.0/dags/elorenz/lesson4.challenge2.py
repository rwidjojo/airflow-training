from datetime import timedelta
import logging

from airflow import DAG
from airflow.utils.dates import days_ago
from airflow.operators.python_operator import PythonOperator
from airflow.hooks.postgres_hook import PostgresHook
from airflow.operators.python_operator import BranchPythonOperator
from airflow.operators.bash_operator import BashOperator

owner = 'elorenz' # Replace with your short name

default_args = {
    'owner': owner,
    'depends_on_past': False,
    'start_date': days_ago(3),
}

dag = DAG(
    f'{owner}.lesson4.challenge2',
    default_args=default_args,
    description='Read data from postgresql',
    schedule_interval=None,
)

branch_even_task = BashOperator(
    task_id ="even_task",
    bash_command ='echo "I am even"',
    dag=dag,
)

branch_odd_task = BashOperator(
    task_id ="odd_task",
    bash_command ='echo "I am odd"',
    dag=dag,
)

def odd_process_task():
    logging.info("odd process run")

odd_process_task= PythonOperator(
    task_id= "odd_process",
    python_callable =odd_process_task,
    dag=dag,
)

def _pick_migration (execution_date, **kwargs):
    if execution_date.day%2 ==0:
        return 'branch_even_task'
    else:
        return 'branch_odd_task'

branch_task= BranchPythonOperator (
    task_id ='branch_task',
    provide_context= True,
    python_callable = _pick_migration,
    dag=dag
)